-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 06 Lis 2020, 22:01
-- Wersja serwera: 10.4.13-MariaDB
-- Wersja PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `local_myshop2`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` mediumint(9) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `admins`
--

INSERT INTO `admins` (`id`, `login`, `password`, `level`, `remember_token`) VALUES
(1, 'admin', '$2y$10$NB4duQzg14FALfJK2476j.m.o1slGxSPS2utCshO/n8pyoz.r1zpG', 1, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `bans`
--

CREATE TABLE `bans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderID` mediumint(9) NOT NULL,
  `overcategory` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `visible` tinyint(4) NOT NULL,
  `icon` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `categories`
--

INSERT INTO `categories` (`id`, `name`, `orderID`, `overcategory`, `active`, `visible`, `icon`) VALUES
(1, 'Elektronika', 3, 0, 1, 1, 'fa-bolt'),
(2, 'Do domu', 1, 0, 1, 1, 'fa-home'),
(4, 'RTV i AGD', 2, 1, 1, 1, 'fa-tv'),
(5, 'Telewizory', 2, 4, 1, 1, 'fa-tv'),
(6, 'Akcesoria', 2, 5, 1, 1, 'fa-tools'),
(7, 'Urządzenia', 1, 5, 1, 1, 'fa-tv'),
(8, 'Tablety', 3, 1, 1, 1, 'fa-tablet-alt'),
(9, 'Kamery', 4, 1, 1, 1, 'fa-camera'),
(10, 'Laptopy', 5, 1, 1, 1, 'fa-laptop'),
(11, 'Karty graficzne', 1, 1, 1, 1, 'fa-microchip');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2019_09_28_080348_create_users_personal', 1),
(4, '2019_09_28_080406_create_users_location', 1),
(5, '2019_09_28_080419_create_users_info', 1),
(6, '2019_09_28_080434_create_categories', 1),
(7, '2019_09_28_080447_create_admins', 1),
(8, '2019_09_29_122005_create_orders', 1),
(9, '2019_09_29_122039_create_products', 1),
(10, '2019_10_01_173104_create_bans', 1),
(11, '2019_10_26_220314_create_products_images', 1),
(12, '2019_10_30_222339_create_payments', 1),
(13, '2019_12_05_081618_create_orders_histories', 1),
(14, '2019_12_12_105617_create_users_histories', 1),
(15, '2019_12_27_221127_create_users_favorites', 1),
(16, '2020_02_18_191734_warehouse_items', 1),
(17, '2020_02_19_200102_create_orders_products', 1),
(18, '2020_02_23_002903_warehouse_items_histories', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('CREATED','UNPAID','PROCESSING','PAID','REALIZE','SENT','RECEIVE','CANCELED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` double(8,2) NOT NULL,
  `buyer_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deliver_name` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deliver_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deliver_parcelID` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` enum('PAYU','PAYPAL','PAYMENTCARD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `status`, `cost`, `buyer_info`, `deliver_name`, `deliver_info`, `deliver_parcelID`, `payment`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, 'PAID', 3062.99, '{\"firstname\":\"Jan\",\"surname\":\"Nowak\",\"phone\":\"111222333\"}', 'COURIER', '{\"district\":\"10\",\"city\":\"Gorz\\u00f3w Wielkopolski\",\"zipcode\":\"66-400\",\"address\":\"Pocztowa 2\"}', NULL, 'PAYPAL', NULL, '2020-02-29 21:50:31', '2020-02-29 21:54:40');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `orders_histories`
--

CREATE TABLE `orders_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `orders_histories`
--

INSERT INTO `orders_histories` (`id`, `order_id`, `data`, `created_at`, `updated_at`) VALUES
(1, 1, 'Stworzono zamówienie', '2020-02-29 21:50:31', '2020-02-29 21:50:31'),
(2, 1, 'Zamiana statusu z CREATED na UNPAID', '2020-02-29 21:50:57', '2020-02-29 21:50:57'),
(3, 1, 'Zamiana statusu z UNPAID na PROCESSING', '2020-02-29 21:53:16', '2020-02-29 21:53:16'),
(4, 1, 'Polecenie transakcji za pomocą: PAYPAL', '2020-02-29 21:53:16', '2020-02-29 21:53:16'),
(5, 1, 'Zamiana statusu z PROCESSING na PAID', '2020-02-29 21:54:40', '2020-02-29 21:54:40');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `orders_products`
--

CREATE TABLE `orders_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_item_id` bigint(20) UNSIGNED NOT NULL,
  `price` double(8,2) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `orders_products`
--

INSERT INTO `orders_products` (`id`, `order_id`, `product_id`, `warehouse_item_id`, `price`, `name`) VALUES
(1, 1, 2, 5, 649.00, 'Gigabyte GeForce GTX 1050 Ti OC 4GB GDDR5'),
(2, 1, 3, 17, 1199.00, 'Gigabyte GeForce GTX 1660 SUPER Gaming OC 6GB GDDR6'),
(3, 1, 3, 19, 1199.00, 'Gigabyte GeForce GTX 1660 SUPER Gaming OC 6GB GDDR6');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `externalID` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('PAYU','PAYPAL','PAYMENTCARD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cancelled` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `payments`
--

INSERT INTO `payments` (`id`, `order_id`, `externalID`, `type`, `amount`, `status`, `cancelled`, `created_at`, `updated_at`) VALUES
(1, 1, 'PAYID-LZNN2RA8JU461453S811934N', 'PAYPAL', 3062.99, 'approved', 0, '2020-02-29 21:50:31', '2020-02-29 21:54:40');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('INVISIBLE','ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `priceCurrent` double(8,2) NOT NULL,
  `priceNormal` double(8,2) NOT NULL,
  `title` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `products`
--

INSERT INTO `products` (`id`, `status`, `category_id`, `priceCurrent`, `priceNormal`, `title`, `description`, `params`) VALUES
(1, 'ACTIVE', 11, 5736.60, 5736.60, 'MSI GeForce RTX 2080Ti GAMING X TRIO', 'Phasellus et dolor non erat elementum pretium sed sit amet ex. Integer quis erat varius, ullamcorper justo nec, molestie dolor. Sed neque nisi, malesuada id dapibus ut, dignissim a mi. Fusce erat tortor, placerat quis viverra vitae, rutrum eu nibh. Etiam id sagittis nisl, sed cursus metus. Donec in fermentum nisl. Vivamus a libero accumsan, malesuada magna quis, molestie est. Donec nisi nisl, ultrices volutpat rhoncus ac, fermentum vel lorem. Maecenas non lectus scelerisque, eleifend felis vel, sollicitudin tortor. Vivamus et tortor vitae arcu ultrices pulvinar.', '[{\"name\":\"AA\",\"value\":\"BB\"}]'),
(2, 'ACTIVE', 11, 649.00, 649.00, 'Gigabyte GeForce GTX 1050 Ti OC 4GB GDDR5', 'Morbi consectetur consectetur tortor, quis sollicitudin enim placerat accumsan. Maecenas vitae lacinia odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin sed orci vehicula, finibus nisi eget, mattis elit. Curabitur massa eros, ultricies vel dolor quis, tincidunt aliquet turpis. Nam cursus laoreet odio, vel elementum urna hendrerit sit amet. Curabitur pellentesque interdum malesuada. Duis ac vulputate massa, in ultrices ex. Aliquam quis nunc sed dolor laoreet pretium in non massa. Sed faucibus justo urna, eu vestibulum mauris consectetur vel.\n\nInterdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur id tincidunt leo. Suspendisse euismod gravida arcu. Aenean ac tortor a ante pharetra pharetra. Donec id eros malesuada, scelerisque nunc sed, commodo erat. Cras imperdiet arcu feugiat, viverra dolor ac, imperdiet ligula. Etiam luctus, sapien sed elementum condimentum, libero ante luctus libero, in scelerisque eros dolor ac ante. Donec facilisis, nibh eget pretium imperdiet, est sem placerat felis, sed fringilla justo erat at lectus. In mattis libero vel dui lacinia tincidunt. Duis non ipsum euismod, aliquam eros tincidunt, rutrum velit. Nam vehicula lectus vel placerat ultricies. Fusce vehicula sem mattis nisl luctus sagittis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris tempus ultricies turpis eu pulvinar. Praesent tempor magna sit amet metus consectetur, eu pulvinar urna vehicula. Quisque ultricies bibendum sem sed euismod.', NULL),
(3, 'ACTIVE', 11, 1199.00, 1199.00, 'Gigabyte GeForce GTX 1660 SUPER Gaming OC 6GB GDDR6', 'Nulla gravida malesuada justo eu accumsan. In iaculis dolor sapien, ut tincidunt augue varius ut. Integer sit amet semper eros, at gravida odio. Praesent condimentum aliquet imperdiet. In sed interdum leo, a vehicula enim. Ut ut arcu eget mi finibus volutpat. Pellentesque lobortis nisi in libero tristique, aliquam consequat magna posuere. Integer vehicula in neque vel vulputate.', NULL),
(4, 'ACTIVE', 5, 3299.99, 3299.99, 'Telewizor Philips 55PUS7504/12 LED 55\" 4K', 'Suspendisse iaculis dui sagittis leo efficitur placerat. Pellentesque condimentum ultrices vulputate. Nunc lacus ex, efficitur sit amet varius nec, commodo sed metus. Maecenas a mauris non dui hendrerit dictum. Suspendisse potenti. Etiam at ligula ac lorem posuere finibus in sit amet ex. Maecenas dictum non lectus et ullamcorper. Aenean faucibus, metus in pellentesque dictum, quam est fringilla nibh, sed porttitor magna mauris eget est. Etiam pretium tortor vel semper viverra. Vivamus mattis et enim in vulputate. Nullam lorem felis, aliquet eget semper non, placerat sit amet ipsum. Praesent bibendum velit erat, eget cursus turpis ullamcorper ut. Vivamus at neque non nisl scelerisque consectetur.', NULL),
(5, 'ACTIVE', 10, 2398.00, 2398.00, 'Laptop Lenovo V130-15IKB', 'Nulla in lacinia quam, nec rhoncus risus. Sed sed aliquam velit, id pulvinar enim. Proin sit amet ex venenatis, faucibus elit sed, suscipit ex. Sed volutpat sit amet odio fermentum congue. In in turpis dictum, placerat nibh et, tempus augue. Sed aliquam turpis at volutpat hendrerit. Etiam quis efficitur massa. Pellentesque in lectus arcu. In ullamcorper, metus ac lacinia faucibus, ex lacus pharetra ligula, non fermentum ante dolor a nisl. Nam eget condimentum ante, non ultricies nunc. Mauris at nisi enim. Sed sed tempor erat.', NULL),
(6, 'ACTIVE', 2, 1590.00, 599.00, 'SZAFA z drzwiami przesuwnymi TALIN III 180 lustro', 'Elegancka rączka\n\nAluminiowe rączki zastosowane w drzwiach przesuwnych podkreślają jej nowoczesny styl, poprawiają jej funkcjonalność oraz zapobiegają wyginaniu się drzwi.\n\nProsto od producenta\n\nSzafa produkowana jest w naszej fabryce. Kupujesz więc prosto od producenta, a dzięki temu masz pewność, że omijasz prowizje od pośredników. O wysoką jakość produkowanego mebla dbają nasi najlepsi i wykwalifikowani pracownicy, a także nowoczesny park maszyn.', NULL),
(7, 'ACTIVE', 2, 899.00, 899.00, 'Narożnik rozkładany rogówka MILO funkcja spania', 'Narożnik Milo z funkcją spania\nidealny mebel do salonu , pokoju itp.\nwygodny i łatwy system rozkładania\ncena narożnika nie obejmuje półki w boczku oraz elementów drewnianych , możliwość dokupienia półki w boczku oraz elementów drewnianych na innej aukcji.\npoduszki w zestawie\npojemna skrzynia na pościel 2 szt.\nNa zdjęciu jest lewy narożnik kupują Państwo Lewo stronny czyli taki jak na zdjęciu na innej aukcji można kupić Prawo stronny\nJESTEŚMY PRODUCENTEM !', NULL),
(8, 'ACTIVE', 2, 809.00, 809.00, 'Narożnik nowoczesny rogówka GUCIO kanapa', 'Narożnik *GUCIO* to elegancki narożnik z funkcją spania. Jest to wyjątkowa konstrukcja w nowoczesnym ale prostym stylu, która może stanowić ozdobę każdego salonu.\n\nDodatkowym atutem naszego mebla jest solidne i dbałe wykonanie, nowy design, oraz nowoczesne i wytrzymałe tkaniny z najnowszych kolekcji w bardzo atrakcyjnej cenie.\n\nEleganckie przeszycia sprawiają że narożnik prezentuje się i wygląda wyjątkowo a ozdobne stópki zapewniają cyrkulację powietrza pod meblami\n\nNarożnik jest dostępny w wielu wariantach kolorystycznych i materiałowych.\n\nMożliwość dokupienia sprężyny bonellowej w narożniku, zapewniają one większy komfort użytkowania oraz zwiększa jego wytrzymałość, a także żywotność.', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `products_images`
--

CREATE TABLE `products_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `products_images`
--

INSERT INTO `products_images` (`id`, `product_id`, `name`) VALUES
(1, 1, '0XUSdhSRbNrUmQB7g5wVbUDWlnMlOqExlm1imIWZ.jpeg'),
(2, 1, 'dOAnk0nhA03tzretH5TgnVCKEdOzga8cFfeL7RNY.jpeg'),
(3, 2, 'OcK8NEygKUQXFtOTowt404HkbPcjIstn1j2zVhak.png'),
(4, 2, 'rHbbaBsKjPtMKnFjuTJpyS6oqsAHN2QccshK7QhU.png'),
(5, 2, 'kG3sARGpYtydTIHGLK6sSCo3puFpTPBV27sguwum.png'),
(6, 3, 'U849R9WKV9JoWzAz1s21YIUoQCh1cpa8naRg2WOr.jpeg'),
(7, 3, 'SlZlIKyJXUTgbXqFNPpumWkacm5BAK3RLx0bWvqc.jpeg'),
(8, 4, 'BAuDSADU1GMF2PKdiqhLBudeIR7eUd8MAsTDfxJG.jpeg'),
(9, 4, '45lJGgV8T4OPPx58RBP8zASRN9J0cNzJ2V0feiPM.jpeg'),
(10, 4, 'BFVt2XimJjktpRmt7Zsm0py8TU0WaCdOkKI0y3Qo.jpeg'),
(11, 5, 'dT3IIyxPdSZDCkzMDfizyMiK46EE9FIyXVdnQhWS.jpeg'),
(12, 5, '80u5GNENqYhbrhNKqNFy8yD74DDQaq62JawWClQH.jpeg'),
(13, 5, '2lyCHKK1BaZmVSlce0LRRCgVpPYrWS3Ai4GUZ9vN.jpeg'),
(14, 6, '5DsJcDGq4kCAqGM0l8fkQgazKTcQJDcovSzzL4aR.jpeg'),
(15, 6, 'xGcMoquSJiupM5iQMU6PbsyKmIatgZAeKvYQRRie.jpeg'),
(16, 6, '5cQq5nJwVqZg8vuuZiYSKFkbx7zCuKyWBhVaWJs0.jpeg'),
(17, 6, 'tlM19kX1XCmWvdnXOBPsdbjvrKB7bzUUxfVcVFnA.jpeg'),
(18, 7, 'ZMCX58BT4078UXOhDYU6JE0E5VzokWq1rpdbUwPB.jpeg'),
(19, 7, 'FMUipGwOkhDWB5Z3tTs9kY6IvYVrG2zELsoN81JX.jpeg'),
(20, 7, 'rqLsYq2O82p8GjNiGQl7S91WLZpW9K4CFpvBwuLx.jpeg'),
(21, 8, 'x39Lu03G2mGrkV1WPApwgJSMw2AQsf9njy5UxW9u.jpeg'),
(22, 8, 'MHpz1XevBg1PiTM43t0nj5JvXCljMwTYguOhqUtg.jpeg');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` smallint(6) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `hash`, `active`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'sebak@myshop.local', '$2y$10$nC/ZY3LQFHqV.MTfpJ7Qre9q5HqRo8pIhPHKOgr/.erdD1YBwxGNO', 'd4a29147050cfd8e83d4ff3806f554230749fc23e72fd24c14915f999e2900eb', 1, NULL, '2020-02-23 21:25:01', '2020-02-23 21:25:40');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users_favorites`
--

CREATE TABLE `users_favorites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `products` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `users_favorites`
--

INSERT INTO `users_favorites` (`id`, `user_id`, `products`) VALUES
(1, 1, '[]');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users_histories`
--

CREATE TABLE `users_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `users_histories`
--

INSERT INTO `users_histories` (`id`, `user_id`, `type`, `data`, `ip`, `created_at`, `updated_at`) VALUES
(1, 1, 'AUTH', 'Stworzono konto', '127.0.0.1', '2020-02-23 21:25:01', '2020-02-23 21:25:01'),
(2, 1, 'AUTH', 'Logowanie do konta... KONTO NIEAKTYWNE', '127.0.0.1', '2020-02-23 21:25:17', '2020-02-23 21:25:17'),
(3, 1, 'AUTH', 'Konto aktywowane przez użytkownika', '127.0.0.1', '2020-02-23 21:25:40', '2020-02-23 21:25:40'),
(4, 1, 'AUTH', 'Logowanie do konta... SUKCES', '127.0.0.1', '2020-02-23 21:25:47', '2020-02-23 21:25:47'),
(5, 1, 'AUTH', 'Logowanie do konta... SUKCES', '127.0.0.1', '2020-02-29 21:46:21', '2020-02-29 21:46:21'),
(6, 1, 'AUTH', 'Logowanie do konta... SUKCES', '127.0.0.1', '2020-05-07 08:47:52', '2020-05-07 08:47:52'),
(7, 1, 'BAN', 'Konto zablokowane z powodu: HEJA HO', '127.0.0.1', '2020-05-07 08:49:16', '2020-05-07 08:49:16'),
(8, 1, 'AUTH', 'Logowanie do konta... KONTO ZABLOKOWANE', '127.0.0.1', '2020-05-07 08:50:01', '2020-05-07 08:50:01'),
(9, 1, 'AUTH', 'Logowanie do konta... KONTO ZABLOKOWANE', '127.0.0.1', '2020-06-24 18:54:06', '2020-06-24 18:54:06'),
(10, 1, 'AUTH', 'Logowanie do konta... SUKCES', '127.0.0.1', '2020-06-24 18:54:36', '2020-06-24 18:54:36');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users_info`
--

CREATE TABLE `users_info` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `firstIP` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activationHash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activationMailTime` int(11) DEFAULT NULL,
  `passwordResetHash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passwordResetMailTime` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `users_info`
--

INSERT INTO `users_info` (`id`, `user_id`, `firstIP`, `activationHash`, `activationMailTime`, `passwordResetHash`, `passwordResetMailTime`) VALUES
(1, 1, '127.0.0.1', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users_location`
--

CREATE TABLE `users_location` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `district` int(11) NOT NULL,
  `city` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `users_location`
--

INSERT INTO `users_location` (`id`, `user_id`, `district`, `city`, `zipcode`, `address`) VALUES
(1, 1, 4, 'Gorzów Wielkopolski', '66-400', 'Pocztowa 2');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users_personal`
--

CREATE TABLE `users_personal` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `users_personal`
--

INSERT INTO `users_personal` (`id`, `user_id`, `firstname`, `surname`, `phoneNumber`) VALUES
(1, 1, 'Jan', 'Nowak', 111222333);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `warehouse_items`
--

CREATE TABLE `warehouse_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('AVAILABLE','UNAVAILABLE','RESERVED','BOUGHT','INVISIBLE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `warehouse_items`
--

INSERT INTO `warehouse_items` (`id`, `product_id`, `code`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'DSADJSAVDHSA', 'AVAILABLE', '2020-02-23 21:26:56', '2020-02-23 21:26:56'),
(2, 1, 'SDBKVADSA', 'UNAVAILABLE', '2020-02-23 21:27:10', '2020-02-23 21:27:10'),
(3, 1, 'OIJYOTYTYTY', 'AVAILABLE', '2020-02-23 21:27:18', '2020-02-23 21:27:18'),
(4, 1, 'SYVDBOWW', 'AVAILABLE', '2020-02-23 21:27:55', '2020-02-29 21:00:46'),
(5, 2, 'KKEEKKK', 'RESERVED', '2020-02-23 21:28:30', '2020-02-29 21:50:31'),
(6, 2, 'QWEEERTR', 'UNAVAILABLE', '2020-02-23 21:28:38', '2020-02-23 21:28:38'),
(7, 5, 'AASSSEEEE', 'AVAILABLE', '2020-02-23 21:28:50', '2020-02-23 21:28:50'),
(8, 8, 'ASDDDEEOO', 'INVISIBLE', '2020-02-23 21:29:05', '2020-02-23 21:29:05'),
(9, 8, 'DSA97321333', 'UNAVAILABLE', '2020-02-23 21:29:15', '2020-02-23 21:29:15'),
(10, 8, 'SA4441SSS', 'UNAVAILABLE', '2020-02-23 21:29:20', '2020-02-23 21:29:20'),
(11, 4, '9OUJ7GBA45O84', 'AVAILABLE', '2020-02-23 21:29:32', '2020-02-23 21:29:32'),
(12, 4, '644WE5W55W', 'AVAILABLE', '2020-02-23 21:29:38', '2020-02-23 21:29:38'),
(13, 4, 'S5S3535S5S', 'AVAILABLE', '2020-02-23 21:29:43', '2020-02-23 21:29:43'),
(14, 4, 'S34S34S3443WS', 'AVAILABLE', '2020-02-23 21:29:47', '2020-02-23 21:29:47'),
(15, 4, 'S34S34S43', 'AVAILABLE', '2020-02-23 21:29:51', '2020-02-23 21:29:51'),
(16, 4, '4S3S434S43S3', 'AVAILABLE', '2020-02-23 21:29:54', '2020-02-23 21:29:54'),
(17, 3, 'A4WA4WA4A4W', 'RESERVED', '2020-02-23 21:30:14', '2020-02-29 21:50:31'),
(18, 3, '4WA4AW4WA4', 'UNAVAILABLE', '2020-02-23 21:30:18', '2020-02-23 21:30:18'),
(19, 3, 'A4W4AW4AW4QAW', 'RESERVED', '2020-02-23 21:30:22', '2020-02-29 21:50:31'),
(20, 6, 'SA5AS1JHGHH', 'UNAVAILABLE', '2020-02-23 21:30:29', '2020-02-23 21:30:29'),
(21, 7, 'A24A2455A345', 'UNAVAILABLE', '2020-02-23 21:30:35', '2020-02-23 21:30:35'),
(22, 7, '4A26666', 'AVAILABLE', '2020-02-23 21:30:39', '2020-02-23 21:30:39'),
(23, 7, 'SSA4AW4AW4', 'AVAILABLE', '2020-02-23 21:30:43', '2020-02-23 21:30:43'),
(24, 7, 'A4AW4AW4', 'AVAILABLE', '2020-02-23 21:30:46', '2020-02-23 21:30:46');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `warehouse_items_histories`
--

CREATE TABLE `warehouse_items_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `warehouse_items_histories`
--

INSERT INTO `warehouse_items_histories` (`id`, `item_id`, `data`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dodano towar do magazynu', '2020-02-23 21:26:56', '2020-02-23 21:26:56'),
(2, 2, 'Dodano towar do magazynu', '2020-02-23 21:27:10', '2020-02-23 21:27:10'),
(3, 3, 'Dodano towar do magazynu', '2020-02-23 21:27:18', '2020-02-23 21:27:18'),
(4, 4, 'Dodano towar do magazynu', '2020-02-23 21:27:55', '2020-02-23 21:27:55'),
(5, 5, 'Dodano towar do magazynu', '2020-02-23 21:28:30', '2020-02-23 21:28:30'),
(6, 6, 'Dodano towar do magazynu', '2020-02-23 21:28:38', '2020-02-23 21:28:38'),
(7, 7, 'Dodano towar do magazynu', '2020-02-23 21:28:50', '2020-02-23 21:28:50'),
(8, 8, 'Dodano towar do magazynu', '2020-02-23 21:29:05', '2020-02-23 21:29:05'),
(9, 9, 'Dodano towar do magazynu', '2020-02-23 21:29:15', '2020-02-23 21:29:15'),
(10, 10, 'Dodano towar do magazynu', '2020-02-23 21:29:20', '2020-02-23 21:29:20'),
(11, 11, 'Dodano towar do magazynu', '2020-02-23 21:29:32', '2020-02-23 21:29:32'),
(12, 12, 'Dodano towar do magazynu', '2020-02-23 21:29:38', '2020-02-23 21:29:38'),
(13, 13, 'Dodano towar do magazynu', '2020-02-23 21:29:43', '2020-02-23 21:29:43'),
(14, 14, 'Dodano towar do magazynu', '2020-02-23 21:29:47', '2020-02-23 21:29:47'),
(15, 15, 'Dodano towar do magazynu', '2020-02-23 21:29:51', '2020-02-23 21:29:51'),
(16, 16, 'Dodano towar do magazynu', '2020-02-23 21:29:54', '2020-02-23 21:29:54'),
(17, 17, 'Dodano towar do magazynu', '2020-02-23 21:30:14', '2020-02-23 21:30:14'),
(18, 18, 'Dodano towar do magazynu', '2020-02-23 21:30:18', '2020-02-23 21:30:18'),
(19, 19, 'Dodano towar do magazynu', '2020-02-23 21:30:22', '2020-02-23 21:30:22'),
(20, 20, 'Dodano towar do magazynu', '2020-02-23 21:30:29', '2020-02-23 21:30:29'),
(21, 21, 'Dodano towar do magazynu', '2020-02-23 21:30:35', '2020-02-23 21:30:35'),
(22, 22, 'Dodano towar do magazynu', '2020-02-23 21:30:39', '2020-02-23 21:30:39'),
(23, 23, 'Dodano towar do magazynu', '2020-02-23 21:30:43', '2020-02-23 21:30:43'),
(24, 24, 'Dodano towar do magazynu', '2020-02-23 21:30:46', '2020-02-23 21:30:46'),
(25, 4, 'Zamiana statusu z BOUGHT na AVAILABLE', '2020-02-29 21:00:46', '2020-02-29 21:00:46'),
(26, 5, 'Zamiana statusu z AVAILABLE na RESERVED', '2020-02-29 21:50:31', '2020-02-29 21:50:31'),
(27, 5, 'Dodano towar do zamwówienia #1', '2020-02-29 21:50:31', '2020-02-29 21:50:31'),
(28, 17, 'Zamiana statusu z AVAILABLE na RESERVED', '2020-02-29 21:50:31', '2020-02-29 21:50:31'),
(29, 17, 'Dodano towar do zamwówienia #1', '2020-02-29 21:50:31', '2020-02-29 21:50:31'),
(30, 19, 'Zamiana statusu z AVAILABLE na RESERVED', '2020-02-29 21:50:31', '2020-02-29 21:50:31'),
(31, 19, 'Dodano towar do zamwówienia #1', '2020-02-29 21:50:31', '2020-02-29 21:50:31');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `bans`
--
ALTER TABLE `bans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bans_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `orders_histories`
--
ALTER TABLE `orders_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_histories_order_id_foreign` (`order_id`);

--
-- Indeksy dla tabeli `orders_products`
--
ALTER TABLE `orders_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_products_order_id_foreign` (`order_id`),
  ADD KEY `orders_products_warehouse_item_id_foreign` (`warehouse_item_id`);

--
-- Indeksy dla tabeli `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_order_id_foreign` (`order_id`);

--
-- Indeksy dla tabeli `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indeksy dla tabeli `products_images`
--
ALTER TABLE `products_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_images_product_id_foreign` (`product_id`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indeksy dla tabeli `users_favorites`
--
ALTER TABLE `users_favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_favorites_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `users_histories`
--
ALTER TABLE `users_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_histories_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_info_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `users_location`
--
ALTER TABLE `users_location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_location_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `users_personal`
--
ALTER TABLE `users_personal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_personal_user_id_foreign` (`user_id`);

--
-- Indeksy dla tabeli `warehouse_items`
--
ALTER TABLE `warehouse_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_items_product_id_foreign` (`product_id`);

--
-- Indeksy dla tabeli `warehouse_items_histories`
--
ALTER TABLE `warehouse_items_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_items_histories_item_id_foreign` (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `bans`
--
ALTER TABLE `bans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT dla tabeli `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT dla tabeli `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `orders_histories`
--
ALTER TABLE `orders_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `orders_products`
--
ALTER TABLE `orders_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT dla tabeli `products_images`
--
ALTER TABLE `products_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT dla tabeli `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `users_favorites`
--
ALTER TABLE `users_favorites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `users_histories`
--
ALTER TABLE `users_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `users_info`
--
ALTER TABLE `users_info`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `users_location`
--
ALTER TABLE `users_location`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `users_personal`
--
ALTER TABLE `users_personal`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `warehouse_items`
--
ALTER TABLE `warehouse_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT dla tabeli `warehouse_items_histories`
--
ALTER TABLE `warehouse_items_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `bans`
--
ALTER TABLE `bans`
  ADD CONSTRAINT `bans_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `orders_histories`
--
ALTER TABLE `orders_histories`
  ADD CONSTRAINT `orders_histories_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Ograniczenia dla tabeli `orders_products`
--
ALTER TABLE `orders_products`
  ADD CONSTRAINT `orders_products_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `orders_products_warehouse_item_id_foreign` FOREIGN KEY (`warehouse_item_id`) REFERENCES `warehouse_items` (`id`);

--
-- Ograniczenia dla tabeli `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Ograniczenia dla tabeli `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Ograniczenia dla tabeli `products_images`
--
ALTER TABLE `products_images`
  ADD CONSTRAINT `products_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- Ograniczenia dla tabeli `users_favorites`
--
ALTER TABLE `users_favorites`
  ADD CONSTRAINT `users_favorites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `users_histories`
--
ALTER TABLE `users_histories`
  ADD CONSTRAINT `users_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `users_info`
--
ALTER TABLE `users_info`
  ADD CONSTRAINT `users_info_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `users_location`
--
ALTER TABLE `users_location`
  ADD CONSTRAINT `users_location_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `users_personal`
--
ALTER TABLE `users_personal`
  ADD CONSTRAINT `users_personal_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `warehouse_items`
--
ALTER TABLE `warehouse_items`
  ADD CONSTRAINT `warehouse_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Ograniczenia dla tabeli `warehouse_items_histories`
--
ALTER TABLE `warehouse_items_histories`
  ADD CONSTRAINT `warehouse_items_histories_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `warehouse_items` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
